const express = require('express');
const app = express();
const ADODB = require('node-adodb');
const path = require('path');

app.get('/', (req, res) => {
    res.send('Servidor rodando...');
});

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});

// Caminho para o banco de dados
const db = ADODB.open(`Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Aluno\\Desktop\\sabor-do-brasil\\sabor_do_brasil.accdb;`);


db.schema(20) // Testando conexão
   .then(data => console.log("Conectado ao banco de dados"))
   .catch(error => console.log(error));

// Serve os arquivos estáticos (CSS, JS, imagens) da pasta public
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});
