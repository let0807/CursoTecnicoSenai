document.addEventListener('DOMContentLoaded', function() {
    // Exemplo de contagem de likes e dislikes
    const likeBtn = document.querySelector('.like-btn');
    const dislikeBtn = document.querySelector('.dislike-btn');
    const commentBtn = document.querySelector('.comment-btn');

    let likes = 0;
    let dislikes = 0;
    let comments = 0;

    likeBtn.addEventListener('click', function() {
        likes++;
        likeBtn.textContent = `👍 ${likes}`;
    });

    dislikeBtn.addEventListener('click', function() {
        dislikes++;
        dislikeBtn.textContent = `👎 ${dislikes}`;
    });

    commentBtn.addEventListener('click', function() {
        comments++;
        commentBtn.textContent = `💬 ${comments}`;
    });
});
